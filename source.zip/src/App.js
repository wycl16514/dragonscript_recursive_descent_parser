import React from "react";
import TerminalEmulator from './components/terminal/terminal'
function App() {
  return (
    <div className="App">
      <TerminalEmulator></TerminalEmulator>
    </div>
  );
}

export default App;
