import RecursiveDescentParser from './recursive_descent_parser'
import Scanner from '../scanner/token'
describe("Testing token scanning from parser", () => {
    it("should get correct tokens by advance", () => {
        const parser = new RecursiveDescentParser("1;")
        const numToken = parser.getToken()
        expect(numToken).toMatchObject({
            lexeme: "1",
            token: Scanner.NUMBER,
            line: 0,
        })
        parser.advance()
        const semiToken = parser.getToken()
        expect(semiToken).toMatchObject({
            lexeme: ";",
            token: Scanner.SEMICOLON,
            line: 0,
        })
    });

    it("should get correct token by previous", () => {
        const parser = new RecursiveDescentParser("1;")
        parser.advance()
        parser.advance()
        parser.previous()
        const numToken = parser.getToken()
        expect(numToken).toMatchObject({
            lexeme: "1",
            token: Scanner.NUMBER,
            line: 0,
        })
    })

    it("should get the last token when calling advance with times more than existing tokens", () => {
        const parser = new RecursiveDescentParser("1;")
        parser.advance()
        parser.advance()
        parser.advance()
        parser.advance()
        const semiToken = parser.getToken()
        expect(semiToken).toMatchObject({
            lexeme: ";",
            token: Scanner.SEMICOLON,
            line: 0,
        })
    })

    it("should get the beginning token when calling previous with times more than existing tokens", () => {
        const parser = new RecursiveDescentParser("1;")
        parser.advance()
        parser.previous()
        parser.previous()
        parser.previous()
        const numToken = parser.getToken()
        expect(numToken).toMatchObject({
            lexeme: "1",
            token: Scanner.NUMBER,
            line: 0,
        })
    })

    it("should get the first token by calling previous withou calling advance at before", () => {
        const parser = new RecursiveDescentParser("1;")
        parser.previous()
        const numToken = parser.getToken()
        expect(numToken).toMatchObject({
            lexeme: "1",
            token: Scanner.NUMBER,
            line: 0,
        })
    })
})

describe("Testing creation of abstract syntax tree ", () => {
    it("should parse expression with only number or string", () => {
        let parser = new RecursiveDescentParser("1;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser('"hello world";')
        expect(parser.parse).not.toThrow()
    })

    it("should parse expression with + and - operatior", () => {
        let parser = new RecursiveDescentParser("1+2;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser('"hello" + "world";')
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser('4 - 3;')
        expect(parser.parse).not.toThrow()
    })

    it("should parse expression with + or - and number with unary operator prefix", () => {
        let parser = new RecursiveDescentParser("-1+2;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("1--2;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("!1-!-2;")
        expect(parser.parse).not.toThrow()
    })

    it("should parse expression with +, -, !, operator and key words", () => {
        let parser = new RecursiveDescentParser("!true;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("!false;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("false + !true;")
        expect(parser.parse).not.toThrow()
        /*
        what this could be? !false evalue to true, then -true evalue to -1,
        what dose it mean adding string with -1? in js it will turn -1 into
        string "-1" and connocate the two string together, then
        "hello" + -!false -> "hello-1", in other language it might be error
        */
        parser = new RecursiveDescentParser('"hello" + -!false;')
        expect(parser.parse).not.toThrow()

        parser = new RecursiveDescentParser('"hello" + -!nil;')
        expect(parser.parse).not.toThrow()
    })

    it("should support operator * and / in expression", () => {
        let parser = new RecursiveDescentParser("1*2+3;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("4/2 - 5;")
        expect(parser.parse).not.toThrow()
    })

    it("should support brackets in expression", () => {
        let parser = new RecursiveDescentParser("1*2+(4-3);")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("!false + (8-2)/3;")
        expect(parser.parse).not.toThrow()
    })

    it("should support comparison operator", () => {
        let parser = new RecursiveDescentParser("1*2+(4-3) > (3+1)/2;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("1*2+(4-3) >= (3+1)/2;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("1*2+(4-3) <= (3+1)/2+4;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("1*2+(4-3) < (3+1)/2+4;")
        expect(parser.parse).not.toThrow()
    })

    it("should support equality operator", () => {
        let parser = new RecursiveDescentParser("1*2+(4-3) > (3+1)/2 == true;")
        expect(parser.parse).not.toThrow()
        parser = new RecursiveDescentParser("1*2+(4-3) > (3+1)/2 != false;")
        expect(parser.parse).not.toThrow()
    })

})
