import Scanner from '../scanner/token'
export default class RecursiveDescentParser {
    constructor(expression) {
        this.source = expression
        this.scanner = new Scanner(expression);
        /*
        save all scanned tokens in the array, we can get previous scanned 
        token by using index
        */
        this.tokens = []
        this.current = -1
        //contains root for each arithmetic express
        this.parseTree = []
        //read the first token
        this.advance()
    }

    getToken = () => {
        return this.tokens[this.current]
    }

    advance = () => {
        if (this.current + 1 >= this.tokens.length) {
            /*
            if current at the end of array, we push a new token
            otherwise there has token ahead of current ,then we just 
            return the next already existing token
            */
            const token = this.scanner.scan()
            if (token.token !== Scanner.EOF) {
                this.tokens.push(token)
                this.current += 1
            }
        }
    }

    previous = () => {
        if (this.current > 0) {
            this.current -= 1
        }
    }

    createParseTreeNode = (name) => {
        return {
            name: name,
            children: [],
            attributes: "",
        }
    }

    matchTokens = (tokens) => {
        //check the given token can match the given tokens or not
        const curToken = this.getToken()
        for (let i = 0; i < tokens.length; i++) {
            if (curToken.token == tokens[i]) {
                return curToken
            }
        }

        return null
    }

    parse = () => {
        //clear the parsing tree
        const treeRoot = this.createParseTreeNode("root")
        //clear all
        this.parseTree = []
        //execute the first rule
        this.statement()
        treeRoot.children = this.parseTree
        return treeRoot
    }

    statement = () => {
        const stmtNode = this.createParseTreeNode("statement")
        //stmt -> expression SEMI
        this.expression(stmtNode)
        const token = this.matchTokens([Scanner.SEMICOLON])
        if (token === null) {
            throw new Error("statement miss matching SEMICOLON")
        }
        this.parseTree.push(stmtNode)
    }

    expression = (parentNode) => {
        //expression -> equality
        const exprNode = this.createParseTreeNode("expression")
        this.equality(exprNode)
        parentNode.children.push(exprNode)
    }

    equality = (parentNode) => {
        //equality -> comparison equality_recursive
        const equNode = this.createParseTreeNode("equality")
        this.comparison(equNode)
        this.equalityRecursive(equNode)
        parentNode.children.push(parentNode)
    }

    comparison = (parentNode) => {
        //comparison -> term comparison_recursive
        const compaNode = this.createParseTreeNode("comparison")
        this.term(compaNode)
        this.comparisonRecursive(compaNode)
        parentNode.children.push(compaNode)
    }

    equalityRecursive = (parentNode) => {
        const opToken = this.matchTokens([Scanner.BANG_EQUAL, Scanner.EQUAL_EQUAL])
        if (!opToken) {
            return
        }
        //equality_recursive -> ("!="|"==") equality
        const equalityRecursiveNode = this.createParseTreeNode("equality_recursive")
        equalityRecursiveNode.attributes = {
            value: opToken.lexeme,
            token: opToken,
        }
        parentNode.children.push(equalityRecursiveNode)
        //over the equality operator
        this.advance()
        this.equality(equalityRecursiveNode)
    }

    comparisonRecursive = (parentNode) => {
        const opToken = this.matchTokens([Scanner.LESS_EQUAL, Scanner.LESS,
        Scanner.GREATER, Scanner.GREATER_EQUAL])
        if (!opToken) {
            //comprison -> epsilon
            return
        }
        //comparison ->  (">" | ">=" | "<" | "<=") comparison
        const comparisonRecursiveNode = this.createParseTreeNode("comparison_recursive")
        comparisonRecursiveNode.attributes = {
            value: opToken.lexeme,
            token: opToken,
        }
        parentNode.children.push(comparisonRecursiveNode)
        //over the comparison operator
        this.advance()
        this.comparison(comparisonRecursiveNode)
    }

    term = (parentNode) => {
        //term -> factor term_recursive
        const term = this.createParseTreeNode("term")
        this.factor(term)
        this.termRecursive(term)
        parentNode.children.push(term)
    }

    termRecursive = (parentNode) => {
        const opToken = this.matchTokens([Scanner.MINUS, Scanner.PLUS])
        if (opToken === null) {
            //term_recursive -> epsilon
            console.log("term recursive epsilon")
            return
        }
        //term_recursive ->  ("-" | "+") term
        let nodeName = ""
        if (opToken.token === Scanner.MINUS) {
            nodeName = "MINUS"
        } else {
            nodeName = "ADD"
        }
        const opNode = this.createParseTreeNode(nodeName)
        opNode.attributes = {
            value: opToken.lexeme,
            token: opToken,
        }
        parentNode.children.push(opNode)
        this.advance()
        this.term(opNode)
    }

    factor = (parentNode) => {
        //factor -> unary factor_recursive
        const factor = this.createParseTreeNode("factor")
        this.unary(factor)
        this.factorRecursive(factor)
        parentNode.children.push(factor)
    }

    factorRecursive = (parentNode) => {
        const opToken = this.matchTokens([Scanner.START, Scanner.SLASH])
        if (opToken === null) {
            //factor_recursive -> epsilon
            return
        }
        //factor_recursive ->  ("*|"/") factor
        const factorRecursiveNode = this.createParseTreeNode("factor_recursive")
        factorRecursiveNode.attributes = {
            value: opToken.lexeme,
            token: opToken,
        }
        parentNode.children.push(factorRecursiveNode)
        this.advance()
        this.factor(factorRecursiveNode)
    }

    unary = (parentNode) => {
        //unary -> primary | unary_recursive 
        /*
        we need to choose one of the two rules, which one should we choose?
        if current token can be matched in primary then choose primary,
        otherwise if the current token is ! or -, then choose unary_recursive
        */
        const unaryNode = this.createParseTreeNode("unary")
        if (this.primary(unaryNode) === false) {
            this.unaryRecursive(unaryNode)
        }
        parentNode.children.push(unaryNode)
    }

    unaryRecursive = (parentNode) => {
        //unary_recursive -> epsilon |("!"|"-") unary
        const opToken = this.matchTokens([Scanner.BANG, Scanner.MINUS])
        if (opToken === null) {
            //unary_recursive -> epsilon 
            return
        }

        //unary_recursive -> ("!"|"-") unary
        let opName = ""
        if (opToken.token === Scanner.BANG) {
            opName = "BANG"
        } else {
            opName = "MINUS"
        }

        const unaryRecursiveNode = this.createParseTreeNode("unary_recursive")
        unaryRecursiveNode.attributes = {
            value: opToken.lexeme,
            token: opToken,
        }
        this.advance()
        parentNode.children.push(unaryRecursiveNode)
        this.unary(unaryRecursiveNode)
    }

    primary = (parentNode) => {
        //primary -> NUMBER | STRING | "true" | "false" | "nil" | "(" expression ")" | epsilon
        const token = this.matchTokens([Scanner.NUMBER, Scanner.STRING,
        Scanner.TRUE, Scanner.FALSE, Scanner.NIL, Scanner.LEFT_PAREN])
        if (token === null) {
            //primary -> epsilon
            return false
        }
        const primary = this.createParseTreeNode("primary")
        primary.attributes = {
            value: token.lexeme,
            token: token,
        }
        parentNode.children.push(primary)
        this.advance()
        //primary -> "(" expression ")"
        if (token.token === Scanner.LEFT_PAREN) {
            this.expression(primary)
            if (!this.matchTokens([Scanner.RIGHT_PAREN])) {
                throw new Error("Miss matching ) in expression")
            }
            //scann over )
            this.advance()
        }
        return true
    }

}